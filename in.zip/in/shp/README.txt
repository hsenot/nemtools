Have used the online service:
http://www.zonums.com/online/kml2shp.php
to convert the network file from KML to shapefile.

Then opened it in QGIS, saved it as shapefile 
Note: without this step, shp2pgsql was complaining there was an erro reading shape object 93